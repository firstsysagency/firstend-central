# Checklist de Validação Zod
- [ ] Todo endpoint POST/PUT/PATCH possui schema Zod associado com `.strict()`.
- [ ] Erros de validação retornam status 400 sem vazar stack trace.
- [ ] Campos de identificador (UUID, slugs, IDs numéricos) usam regex específico.
