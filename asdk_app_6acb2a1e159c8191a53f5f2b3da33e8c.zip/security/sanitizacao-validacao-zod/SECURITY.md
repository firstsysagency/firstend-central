---
name: sanitizacao-validacao-zod
description: Validação defensiva de entrada baseada em contrato tipado estrito com Zod.
version: 1.0.0
category: hardening
severity: critico
compliance: OWASP Top 10 (A03, A04)
---

# Sanitização de Entrada e Validação com Zod

## Regras Inegociáveis
1. **Schema Estrito (.strict()):** Nenhum campo extra desconhecido pode ser aceito em formulários ou payloads de API.
2. **Validação Antes da Execução:** O safeParse deve rodar antes de qualquer processamento de negócio ou consulta ao banco.
3. **Higienização de Strings:** Strings de texto livre devem ser aparadas (`.trim()`) e validadas contra limites de tamanho.
