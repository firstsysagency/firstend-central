---
name: postgres-rls-multitenant
description: Isolamento absoluto de dados multitenant usando Row Level Security no PostgreSQL.
version: 1.0.0
category: banco_de_dados
severity: critico
compliance: OWASP A01, LGPD
---

# Row Level Security (RLS) no PostgreSQL

## Arquitetura de Isolamento
1. **Ativação de RLS na Tabela:**
   ```sql
   ALTER TABLE leads ENABLE ROW LEVEL SECURITY;
   ALTER TABLE leads FORCE ROW LEVEL SECURITY;
   ```
2. **Definição de Política por Tenant Context:**
   ```sql
   CREATE POLICY tenant_isolation_policy ON leads
     FOR ALL
     USING (organization_id = NULLIF(current_setting('app.current_org_id', true), ''))
     WITH CHECK (organization_id = NULLIF(current_setting('app.current_org_id', true), ''));
   ```
3. **Injeção de Contexto no Pool de Conexões:**
   - Antes de cada query, a aplicação executa: `SET LOCAL app.current_org_id = 'org_xyz';`.
