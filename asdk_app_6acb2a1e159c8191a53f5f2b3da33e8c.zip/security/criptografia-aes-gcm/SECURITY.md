---
name: criptografia-aes-gcm
description: Criptografia autenticada AES-256-GCM para armazenamento seguro de chaves e dados sensíveis.
version: 1.0.0
category: criptografia
severity: critico
compliance: NIST SP 800-38D, LGPD
---

# Criptografia de Dados Sensíveis AES-256-GCM

## Requisitos Criptográficos
- **Algoritmo:** `aes-256-gcm`
- **Tamanho da Chave:** 256 bits (32 bytes binários derivados via PBKDF2 ou chave mestra de alta entropia).
- **Initialization Vector (IV):** 12 bytes (96 bits) gerados aleatoriamente com CSPRNG (`crypto.randomBytes(12)`) para **cada** operação de criptografia. Nunca reusar o mesmo IV.
- **Tag de Autenticação:** 16 bytes (128 bits) gerada pelo GCM e validada na decifragem antes de liberar o plaintext.
- **Formato de Armazenamento:** `iv_hex:auth_tag_hex:ciphertext_hex`.
