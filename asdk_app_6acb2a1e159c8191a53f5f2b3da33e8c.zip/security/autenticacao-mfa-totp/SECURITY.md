---
name: autenticacao-mfa-totp
description: Padrão corporativo de autenticação multifator e sessões OAuth 2.1 protegidas com PKCE.
version: 1.0.0
category: autenticacao
severity: critico
compliance: NIST SP 800-63B, OAuth 2.1
---

# Autenticação Segura MFA / TOTP e OAuth 2.1

## Padrões de Segurança
- **TOTP (RFC 6238):** Passo de tempo de 30 segundos, algoritmo HMAC SHA-1/SHA-256 com janela de tolerância máxima de ±1 passo.
- **Armazenamento de Segredos TOTP:** O segredo base32 deve ser criptografado em repouso com o cofre AES-256-GCM.
- **OAuth 2.1 com PKCE Obrigatório:**
  - Código de autorização de uso único com expiração em 5 minutos.
  - `code_challenge_method=S256` obrigatório para clientes confidenciais e públicos.
  - Rotação estrita de refresh token com invalidação automática de toda a família de tokens caso um token antigo seja reutilizado.
