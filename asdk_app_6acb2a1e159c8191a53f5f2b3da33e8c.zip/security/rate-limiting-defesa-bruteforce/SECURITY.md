---
name: rate_limiting_defesa_bruteforce
description: Estratégia de rate limit escalonada por sensibilidade de endpoint.
version: 1.0.0
category: rede_api
severity: alto
compliance: OWASP API4
---

# Controle de Taxa (Rate Limit) e Defesa Brute Force

## Escalonamento de Limites
1. **Rotas Críticas de Autenticação (/login, /oauth/token, /mfa):**
   - Limite: 5 requisições por janela de 15 minutos por IP/usuário.
   - Resposta: HTTP 429 Too Many Requests com cabeçalho `Retry-After`.
2. **Rotas Gerais de API (/api/*, /mcp/*):**
   - Limite: 100 a 300 requisições por minuto por chave/token.
3. **Cabeçalhos Padrão RFC 6585:**
   - `RateLimit-Limit`, `RateLimit-Remaining`, `RateLimit-Reset`.
