---
name: protecao-anti-ssrf-webhooks
description: Bloqueio estrito de SSRF para chamadas externas e validação criptográfica de webhooks.
version: 1.0.0
category: rede_api
severity: critico
compliance: OWASP Top 10 (A10)
---

# Proteção Anti-SSRF e Validação de Webhooks

## Regras de Requisições HTTP de Saída (Outbound)
1. **Resolução DNS Antecipada:** Antes de fazer fetch, resolver o hostname e verificar se o IP resultante pertence a faixas privadas:
   - `127.0.0.0/8` (Loopback)
   - `10.0.0.0/8`, `172.16.0.0/12`, `192.168.0.0/16` (RFC 1918)
   - `169.254.169.254` (Link-Local / Metadados de Nuvem)
2. **Apenas Protocolos HTTP e HTTPS:** Bloquear `file://`, `gopher://`, `ftp://`, etc.
3. **Webhooks Assinados:** Todo webhook recebido deve verificar a assinatura HMAC SHA-256 no header com chave secreta compartilhada em tempo constante (`timingSafeEqual`).
