---
name: prevencao-sql-injection
description: Diretrizes de escrita de queries SQL com prepared statements e isolamento de banco.
version: 1.0.0
category: banco_de_dados
severity: critico
compliance: OWASP Top 10 (A03)
---

# Prevenção contra SQL Injection

## Práticas Obrigatórias
- **Zero Concatenação de SQL:** Nunca utilize template strings (`${var}`) ou concatenação com `+` em consultas SQL.
- **Parâmetros Tipados:** Sempre use placeholders posicionais (`$1, $2` no PostgreSQL) gerenciados pelo driver do banco.
- **Usuário da Aplicação Sem Privilégios de DDL:** O usuário de conexão em produção não deve ter permissão de `DROP TABLE`, `ALTER TABLE` ou criar bancos.
