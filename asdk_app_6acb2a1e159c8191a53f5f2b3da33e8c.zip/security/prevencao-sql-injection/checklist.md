# Checklist contra SQL Injection
- [ ] Todas as consultas SQL usam prepared statements ou ORM seguro.
- [ ] Nenhum parâmetro de entrada do usuário é concatenado diretamente na cláusula WHERE ou ORDER BY.
- [ ] Credenciais do banco não usam o usuário 'postgres' (superusuário) na aplicação.
