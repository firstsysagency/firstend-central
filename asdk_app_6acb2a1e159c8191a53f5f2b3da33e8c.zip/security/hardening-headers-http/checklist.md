# Checklist de Auditoria: Headers HTTP
- [ ] O pacote `helmet` está instalado e ativado no topo da stack de middlewares.
- [ ] O cabeçalho `X-Powered-By` está ausente nas respostas.
- [ ] O HSTS está configurado com validade de pelo menos 1 ano (31536000s).
- [ ] Teste de cabeçalhos com securityheaders.com atinge nota A+.
