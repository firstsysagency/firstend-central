---
name: hardening-headers-http
description: Padrão oficial de cabeçalhos HTTP com Helmet para proteção de aplicações web.
version: 1.0.0
category: hardening
severity: alto
compliance: OWASP Top 10 (A05)
---

# Hardening de Headers HTTP e Políticas de Navegador

## Objetivo
Garantir que todo tráfego web trafegue sob HTTPS estrito com cabeçalhos de segurança defensivos configurados via middleware oficial Helmet.

## Diretrizes de Implementação
1. **HSTS Obrigatório:** `Strict-Transport-Security: max-age=31536000; includeSubDomains; preload`
2. **Anti-Clickjacking:** `X-Frame-Options: SAMEORIGIN` ou `frame-ancestors 'self'` via Content Security Policy.
3. **No-Sniff:** `X-Content-Type-Options: nosniff` para impedir interpretação de arquivos como scripts executáveis.
4. **Política de Referrer:** `Referrer-Policy: strict-origin-when-cross-origin`.
5. **Supressão de Fingerprinting:** Remover cabeçalho `X-Powered-By`.
