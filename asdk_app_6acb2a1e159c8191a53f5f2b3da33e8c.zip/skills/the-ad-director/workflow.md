# Workflow: The Ad Director
1. **Passo 1 (/ad-assets):** Mapeamento do público, estilo visual do produto e referências cinematográficas.
2. **Passo 2:** Estruturação da curva dramática: Gancho (0-3s) -> Tensão/Desejo (3-15s) -> Revelação/Clímax (15-25s) -> CTA e Logo (25-30s).
3. **Passo 3 (/ad-director):** Escrita detalhada das tomadas 1 a N.
4. **Passo 4:** Exportação dos prompts mestres otimizados para Runway Gen-3 e Kling.
