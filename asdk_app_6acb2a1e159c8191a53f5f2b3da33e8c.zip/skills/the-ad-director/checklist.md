# Checklist do Diretor
- [ ] O primeiro shot captura a atenção em menos de 2 segundos?
- [ ] A continuidade de iluminação e figurino é mantida entre as cenas?
- [ ] Os prompts contêm descrições de lentes cinematográficas em vez de adjetivos genéricos?
- [ ] O áudio sugerido complementa o ritmo das transições visuais?
