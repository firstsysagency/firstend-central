---
name: paper-cut-motion
description: "Criação de animações artesanais em stop-motion de papel recortado e colagem (Paper Collage), construindo cenas táteis peça por peça com sombras físicas e movimento a 12 FPS."
---

# Paper-Cut Motion (Stop-Motion Paper Collage)

## Objetivo
Transformar conceitos abstratos, histórias de marcas e anúncios em animações stop-motion artesanais no estilo "paper collage" (colagem de papel recortado e rasgado), criando textura tátil e identidade visual inesquecível.

## Comando de Ativação
- `/motion-design`: Inicia a construção da cena stop-motion em papel recortado.

## Pipeline em 3 Prompts Encadeados

### 1. Definição da Cena e Paleta
- Escolha da textura base (papel kraft, cartolina texturizada, papel de jornal antigo, papel aquarela com fibras visíveis).
- Paleta de 4 a 5 cores contrastantes com saturação orgânica de tintas de serigrafia.

### 2. Decomposição em Camadas Físicas
- Cada elemento é descrito como um recorte individual de papel com:
  - Bordas rasgadas (`torn paper edges`) ou corte limpo de estilete (`precise x-acto cut`).
  - Sombra projetada de profundidade (`drop shadow indicating layered paper depth`).
  - Iluminação direcional quente com luz lateral que ressalta os relevos.

### 3. Prompt de Movimento (Runway Gen-3 / Kling / Midjourney)
- Configuração de framerate clássico de stop-motion: **12 FPS** (dois quadros por movimento).
- Substituição física sutil de peças entre frames (`jitter`, `tactile stop-motion jitter`).
- Instrução mestre:
  ```text
  A stop-motion paper cutout collage animation, crafted from textured colored paper layers with visible torn fiber edges. A handcrafted paper character moves through a multi-layered paper cut landscape, 12 fps stop motion jitter, directional warm studio side-lighting casting tangible paper drop shadows, tactile tactile artisan feel, 8k quality, cinematic depth.
  ```
