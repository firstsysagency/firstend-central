# Checklist de Qualidade: Paper-Cut
- [ ] As fibras e bordas rasgadas de papel estão visíveis?
- [ ] Há sombras de contato entre as camadas de papel?
- [ ] O movimento preserva o ritmo de stop-motion (sem interpolação digital excessiva)?
- [ ] A iluminação ressalta a profundidade do diorama?
