# Workflow: Paper-Cut Motion
1. **Passo 1 (Conceituação):** Defina a mensagem da marca e o objeto central em papel.
2. **Passo 2 (Camadas):** Liste as 3 a 5 camadas de papel (fundo, meio, personagem/produto, primeiro plano).
3. **Passo 3 (Geração de Imagem):** Gere o quadro de referência estático via Midjourney v6.1.
4. **Passo 4 (Animação):** Transponha para gerador de vídeo (Runway Gen-3 / Kling) fixando a taxa de 12 FPS.
