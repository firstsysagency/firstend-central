# Matriz de Roteamento Departamental

| Tipo de Solicitação | Departamento Destino | Prioridade Padrão |
|----------------------|----------------------|-------------------|
| Boleto / 2ª via      | Financeiro           | Média             |
| Erro 500 / Sistema   | Suporte N2           | Alta              |
| Novo contrato        | Comercial            | Alta              |
| Dúvida de uso        | Atendimento N1       | Normal            |
