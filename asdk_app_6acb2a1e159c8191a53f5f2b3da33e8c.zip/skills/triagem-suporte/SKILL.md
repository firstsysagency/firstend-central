---
name: triagem-suporte
description: "Identificação de solicitações técnicas, financeiras e contratuais, roteando para os departamentos corretos no CRM."
---

# Skill: Triagem e Roteamento de Suporte

## Objetivo
Detectar a natureza do chamado do cliente no WhatsApp e transferir para o time responsável com contexto estruturado.

## Mapeamento de Departamentos
- **Dúvidas de Cobrança / Boletos / NFs:** Atribuir ao Departamento Financeiro.
- **Problemas Técnicos e Bugs:** Coletar print ou descrição detalhada e atribuir ao Suporte Técnico Nível 2.
- **Renovação de Contrato / Upgrade:** Atribuir ao Comercial.
