# Workflow: Escolha do Formato Criativo
- Para produtos com apelo tátil/infantil/artesanal -> Use `/claymation`.
- Para produtos sustentáveis/design/arquitetura -> Use `/paper-animation`.
- Para marcas jovens/lifestyle/tendências virais -> Use `/song-style-ad`.
- Para produtos funcionais do dia a dia -> Use `/talking-object`.
- Para produtos de B2B, tecnologia ou que resolvem dores de lentidão -> Use `/skeleton-ads`.
