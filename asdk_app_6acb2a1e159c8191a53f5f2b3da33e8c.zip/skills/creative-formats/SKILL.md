---
name: creative-formats
description: "Cinco formatos criativos disruptivos para anúncios de alto engajamento: Claymation (massinha), Animação de Papel, Videoclipe Musical, Objetos Falantes e Esqueletos Cômicos."
---

# Creative Formats (5 Differentiated Looks)

## Objetivo
Superar a fadiga de anúncios convencionais com 5 estilos visuais altamente memoráveis, divertidos e com alto poder de retenção em feeds do Instagram, TikTok e YouTube Shorts.

## Comandos dos 5 Formatos

### 1. `/claymation` - Animação de Massinha
- Estilo artesanal inspirado na Aardman Animations (Wallace & Gromit, A Fuga das Galinhas).
- Textura de argila com impressões digitais sutis, pequenas imperfeições e ritmo de 12 FPS com iluminação de stop-motion quente.

### 2. `/paper-animation` - Diorama de Papel Mecânico
- Cenários em camadas tridimensionais de papel dobrado, engrenagens de papelão e autômatos mecânicos com luz volumétrica.

### 3. `/song-style-ad` - Comercial Videoclipe Musical
- Criação de letras com rimas viciantes, jingle chiclete, sincronia de corte na batida e coreografia divertida com o produto.

### 4. `/talking-object` - Objeto Falante com Personalidade
- O próprio produto (uma garrafa térmica, um tênis, um pacote de café) ganha olhos expressivos, boca animada e dialoga diretamente com o consumidor com humor autodepreciativo ou conselhos francos.

### 5. `/skeleton-ads` - O Esqueleto Cômico
- Um esqueleto bem-humorado em situações cotidianas representando a espera insana por soluções ruins do mercado até descobrir o produto da marca (*"Esperando meu outro fornecedor responder o orçamento..."*).
