# Checklist do Packshot
- [ ] As letras do rótulo estão nítidas e legíveis?
- [ ] O material do frasco/embalagem parece autêntico ao toque?
- [ ] A sombra projetada na base tem gradiente suave e contato físico natural?
