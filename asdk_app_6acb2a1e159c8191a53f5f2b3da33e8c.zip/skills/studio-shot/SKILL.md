---
name: studio-shot
description: "Transformação de fotos comuns de produtos em packshots de estúdio comercial de alto nível, com iluminação de 3 pontos, reflexos realistas e rótulos nítidos."
---

# Studio Shot (Clean Packshots)

## Objetivo
Elevar fotos de celulares ou produtos brutos ao padrão de catálogos internacionais de marcas como Sephora, Apple e Aesop, com superfícies de estúdio impecáveis (mármore polido, concreto arquitetônico, acrílico fosco) e fidelidade aos materiais.

## Comando de Ativação
- `/studio-shot`: Transforma o briefing ou foto bruta em packshot de estúdio comercial.

## Esquemas de Iluminação Profissional
- **Key Light (Luz Principal):** Softbox difuso a 45 graus proporcionando iluminação suave sem estourar reflexos no produto.
- **Fill Light (Luz de Preenchimento):** Painel refletor branco suavizando as sombras laterais.
- **Rim Light (Luz de Borda):** Foco sutil atrás do produto destacando a linha de contorno contra o fundo.
- **Abertura e Foco:** Abertura `f/8` ou `f/11` para profundidade de campo total no produto com desfoque elegante apenas no fundo infinito.
