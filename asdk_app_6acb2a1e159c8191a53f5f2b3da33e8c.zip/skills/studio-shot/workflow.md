# Workflow: Studio Packshot
1. **Passo 1:** Analise o material do produto (vidro translúcido, alumínio escovado, cerâmica fosca, papelão impresso).
2. **Passo 2:** Escolha a superfície de apoio que harmoniza com a paleta da embalagem.
3. **Passo 3:** Configure a iluminação de estúdio adequada para evitar reflexos indesejados.
4. **Passo 4:** Gere o prompt fotográfico técnico com detalhes de lente macro 100mm.
