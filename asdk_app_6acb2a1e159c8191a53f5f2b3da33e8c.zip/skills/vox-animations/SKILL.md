---
name: vox-animations
description: "Roteirização e direção de arte para vídeos explicativos no estilo investigativo e visual do canal Vox, com mapas 3D animados, jornais recortados e gráficos dinâmicos."
---

# Vox Animations (Investigative Explainer Videos)

## Objetivo
Criar vídeos educativos e jornalísticos de altíssimo engajamento no estilo dos canais Vox e Johnny Harris, combinando recortes de documentos históricos, mapas 3D com relevo topográfico, linhas de dados animadas e ritmo narrativo instigante.

## Comando de Ativação
- `"let's make a video"`: Inicia a estruturação completa do vídeo investigativo.

## Elementos de Linguagem Vox
1. **O Gancho de Curiosidade:** O vídeo sempre abre com uma anomalia ou pergunta contraintuitiva (*"Por que esse pequeno país no meio do Pacífico tem mais dinheiro que a Suíça?"*).
2. **Colagem Multimídia Ágil:** Mistura de arquivos confidenciais reais, fotografias antigas com recorte manual, caneta marca-texto amarela sublinhando trechos de jornais e gráficos minimalistas.
3. **Mapas Topográficos 3D:** Câmera que mergulha do espaço em ângulo inclinado sobre montanhas e fronteiras territoriais.
4. **Paleta Clássica Vox:** Fundo creme/papel (`#F4F0EA`), amarelo vibrante de destaque (`#FFDE00`) e preto editorial (`#1A1A1A`).
