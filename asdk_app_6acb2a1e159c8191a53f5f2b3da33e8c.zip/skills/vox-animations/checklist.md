# Checklist Vox
- [ ] Há um elemento visual mudando a cada 3 a 5 segundos?
- [ ] O mapa ou gráfico é imediatamente compreensível sem esforço?
- [ ] A marca-texto amarela guia a leitura no momento certo?
