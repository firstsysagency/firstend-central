# Workflow: Vox Explainer
1. **Passo 1 (A Pergunta):** Formule a tese central investigativa.
2. **Passo 2 (Os Documentos):** Selecione os 3 a 5 dados ou gráficos comprobatórios.
3. **Passo 3 (Storyboard de Motion):** Alterne a cada 4 segundos entre narrador, mapa 3D e recorte de jornal.
4. **Passo 4 (Sound Design):** Inclua cliques de máquina de escrever, som de papel folheando e trilha de suspense suave.
