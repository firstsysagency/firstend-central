# Workflow: Consistência de Personagem
1. **Passo 1 (/image-prompter):** Defina o nome, idade, traços étnicos e roupas âncora do personagem.
2. **Passo 2:** Gere a Character Sheet em grid 3x2 no Midjourney usando `character turnaround sheet`.
3. **Passo 3:** Isole o quadro mestre e utilize como referência permanente (`--cref`).
4. **Passo 4 (/video-prompter):** Crie as ações de vídeo com transições suaves que não deformem o rosto.
