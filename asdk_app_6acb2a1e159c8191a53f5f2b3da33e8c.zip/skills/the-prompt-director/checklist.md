# Checklist de Consistência
- [ ] O formato dos olhos e nariz permanece idêntico em todos os planos?
- [ ] A roupa não sofreu mutações mágicas entre tomadas?
- [ ] O movimento de vídeo preserva a estrutura óssea do rosto?
