---
name: the-prompt-director
description: "Engenharia de prompts para consistência estrita de personagens entre múltiplos quadros e vídeos de IA, com character sheet de 6 ângulos e travamento facial."
---

# The Prompt Director (Character-to-Video Consistency)

## Objetivo
Resolver o maior desafio da produção audiovisual com IA: manter o mesmo personagem com as mesmas feições, cabelo, roupas, proporções e estilo através de múltiplos planos, ângulos e transições para vídeo.

## Comandos de Ativação
- `/image-prompter`: Cria a matriz completa de consistência de imagem e a folha de personagem (Character Sheet).
- `/video-prompter`: Traduz as poses e ações estáticas em prompts de movimento para Runway Gen-3 e Kling preservando a identidade.

## A Folha de Personagem em 6 Ângulos (Character Sheet)
1. **Frontal:** Visão direta nos olhos com expressão neutra.
2. **Três Quartos Esquerda:** Visão em ângulo de 45 graus.
3. **Três Quartos Direita:** Ângulo oposto com a mesma luz.
4. **Perfil Lateral:** Alinhamento do nariz, queixo e linha da mandíbula.
5. **Costas / Silhueta:** Verificação de comprimento de cabelo e corte de roupa.
6. **Expressão Emocional:** Sorriso largo ou choque dramático.

## Âncoras Imutáveis de Prompt
- **Roupas:** Descrição física exata com cores HEX (ex: `wearing a bespoke navy wool jacket #0A192F with brass buttons`).
- **Olhos e Cabelo:** Descrição de tom, formato e estilo imutáveis.
- **Semente e Peso:** Travamento de sementes e referências com URLs de imagem (`--sref` e `--cref` no Midjourney).
