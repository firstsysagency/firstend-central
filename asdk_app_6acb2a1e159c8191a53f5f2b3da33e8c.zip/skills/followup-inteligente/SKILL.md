---
name: followup-inteligente
description: "Cadência automatizada de reengajamento para contatos sem resposta recente, quebrando objeções comuns e resgatando oportunidades."
---

# Skill: Follow-up e Reengajamento Inteligente

## Objetivo
Reconectar com leads e clientes que pararam de responder após o envio de apresentação ou proposta comercial.

## Estratégia de Cadência
- **D+1 (24 horas após envio):** Mensagem de cortesia perguntando se conseguiu visualizar o material.
- **D+3 (72 horas):** Envio de case de sucesso do mesmo nicho do lead.
- **D+7 (Última tentativa amigável):** Pergunta direta de fechamento ou encerramento temporário de contato.

## Instruções para a IA
- Sempre verifique o histórico antes de enviar nova mensagem.
- Respeite o tom humanizado e jamais envie mensagens robotizadas ou insistentes demais.
