# Prompt de Reengajamento Não Invasivo

Seja breve e nunca pareça cobrador. Use perguntas abertas focadas no interesse do lead:
- "Oi {{nome}}, conseguiu dar uma olhada na proposta que te enviei ontem?"
- "Passando só para compartilhar esse caso de um cliente que reduziu tempo de resposta em 85%."
