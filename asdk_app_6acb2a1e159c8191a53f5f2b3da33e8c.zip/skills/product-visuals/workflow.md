# Workflow: Lifestyle Visuals
1. **Passo 1:** Escolha entre Recreate (copiar setup de foto de referência) ou Recompose (criar nova cena temática).
2. **Passo 2:** Defina a hora do dia (golden hour, meio-dia ensolarado, crepúsculo azul).
3. **Passo 3:** Ajuste a luz ambiente refletida no produto (`ambient light bleed`) para que a cor do ambiente banhe sutilmente as bordas do objeto.
4. **Passo 4:** Renderize com lente 50mm ou 85mm com desfoque de fundo suave.
