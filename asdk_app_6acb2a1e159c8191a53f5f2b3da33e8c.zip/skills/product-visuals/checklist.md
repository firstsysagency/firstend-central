# Checklist Lifestyle
- [ ] O produto parece verdadeiramente repousar sobre a superfície (sem parecer colado artificialmente)?
- [ ] A direção da luz solar ou artificial no ambiente é a mesma que atinge o produto?
- [ ] As pessoas ou elementos secundários de fundo não roubam o protagonismo do produto?
