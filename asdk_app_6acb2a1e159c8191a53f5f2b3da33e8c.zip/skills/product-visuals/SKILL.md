---
name: product-visuals
description: "Inserção de produtos em cenários de estilo de vida cinematográficos, oferecendo modos Recreate (mesmo enquadramento/luz) e Recompose (leitura da cena)."
---

# Product Visuals (Lifestyle & Cinematic)

## Objetivo
Inserir produtos em cenas de uso cotidiano de alto padrão (mesas de café iluminadas pelo sol da manhã, bancadas de banheiro de spa luxuoso, cabines de avião de primeira classe, caminhadas em florestas alpinas) mantendo o produto com integração de luz perfeita.

## Comando de Ativação
- `/product-visuals`: Inicia a ambientação do produto em cenários de estilo de vida.

## Modos Operacionais
1. **Modo Recreate:**
   - O usuário fornece uma foto de referência de campanha de outra marca com luz e composição desejadas.
   - A IA recria exatamente a mesma composição, profundidade de campo e iluminação, substituindo o objeto pelo produto do usuário.
2. **Modo Recompose:**
   - A IA analisa a proposta de valor do produto e propõe 3 novos cenários de narrativa visual onde o produto vive naturalmente.
   - Exemplo: um isotônico artesanal repousando sobre uma rocha úmida com névoa matinal e atletas ao fundo desfocados.
