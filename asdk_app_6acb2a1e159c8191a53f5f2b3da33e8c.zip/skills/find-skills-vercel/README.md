# Vercel Find Skills Reference

Inspirado no ecossistema Vercel AI SDK e repositórios abertos de skills para agentes.
Permite aos agentes localizar scripts de automação e templates reutilizáveis.
