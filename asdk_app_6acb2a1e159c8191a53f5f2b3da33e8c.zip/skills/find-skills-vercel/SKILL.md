---
name: find-skills-vercel
description: "Motor de descoberta semântica e busca de skills e plugins para ecossistemas modernos de IA e desenvolvimento web."
---

# Find Skills - Vercel Integration

## Visão Geral
Esta skill fornece capacidades de busca inteligente, recomendação de ferramentas baseadas no contexto de desenvolvimento de software e emparelhamento de plugins sob demanda.

## Casos de Uso
1. Identificar se uma determinada demanda já possui uma skill ou biblioteca testada.
2. Sugerir bibliotecas modernas mantidas e sem risco de segurança na cadeia de suprimentos.
