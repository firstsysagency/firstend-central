/**
 * Script de descoberta de skills (apenas leitura de metadados)
 * NOTA DE SEGURANÇA: Execução automática desabilitada. Tratado apenas como referência estruturada.
 */
export interface SkillSearchResult {
  slug: string;
  relevanceScore: number;
  tags: string[];
}
