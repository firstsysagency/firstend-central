# Template de Encerramento de Qualificação Positiva

"Excelente, {{nome}}! Com base no seu volume de {{volume}} atendimentos, nossa tecnologia consegue economizar cerca de 70% do seu tempo manual. 
Vou passar seu contato para o nosso consultor especialista agendar uma demonstração rápida de 15 minutos com você ainda hoje. Qual o melhor horário?"
