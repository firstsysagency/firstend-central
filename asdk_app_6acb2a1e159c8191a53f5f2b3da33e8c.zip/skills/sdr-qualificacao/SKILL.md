---
name: sdr-qualificacao
description: "Skill para conduzir conversas de qualificação de leads via WhatsApp, aplicando metodologia BANT e coletando dores e orçamento."
---

# Skill: Qualificação e SDR Automatizado

## Objetivo
Qualificar leads recebidos pelo WhatsApp identificando com precisão necessidade, autoridade, orçamento e timing (BANT), preparando a oportunidade para o time de vendas da Firstsys ou do CRM Zatten.

## Diretrizes de Comportamento
1. Faça perguntas curtas e empáticas (máximo 2 frases por mensagem).
2. Identifique o segmento do cliente e volume atual de atendimento.
3. Quando o lead atender aos critérios de qualificação, mova-o no Kanban para a coluna 'Qualificado' e atribua ao time comercial.
4. Caso o lead informe dados de contato ou empresa, salve nas propriedades customizadas correspondentes.

## Gatilhos de Notificação
- Quando o lead solicitar proposta ou reunião imediatamente, execute a ferramenta correspondente com título 'Lead Quente Solicitou Contato'.
