---
name: vibe-coding-toolkit
description: "Conjunto de boas práticas de desenvolvimento ágil assistido por IA, validação contínua de tipos, testes e prevenção de código duplicado."
---

# Vibe Coding Toolkit: Engenharia e Quality Gates

## Diretrizes de Qualidade
1. **Inspeção Prévia (Look Before You Leap):** Nunca presuma a ausência de um arquivo. Inspecione sempre antes de criar ou modificar.
2. **Edição Cirúrgica:** Nunca sobrescreva um arquivo inteiro quando edições pontuais bastam.
3. **Typecheck Contínuo:** Valide com o compilador TypeScript antes de declarar uma tarefa concluída.
4. **Prevenção de Código Duplicado:** Reutilize módulos e componentes existentes.
