# Boas Práticas de Engenharia Firstsys

- **Frontend:** React 19, TypeScript estrito, Framer Motion a 60 FPS estáveis, Tailwind CSS v4.
- **Backend:** Node.js ESM, Express, Schemas Zod, Hash SHA-256 para integridade.
- **Segurança:** Zod strict, sanitização de caminhos (anti-traversal), zero secrets no cliente.
