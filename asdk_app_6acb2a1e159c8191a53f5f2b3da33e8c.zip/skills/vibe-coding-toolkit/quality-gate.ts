/**
 * Quality Gate Linter Rules
 * Exemplo de especificação de regras estáticas de engenharia Firstsys.
 */
export const QUALITY_STANDARDS = {
  zeroAnyTypes: true,
  explicitReturnType: true,
  noDeadCode: true
};
