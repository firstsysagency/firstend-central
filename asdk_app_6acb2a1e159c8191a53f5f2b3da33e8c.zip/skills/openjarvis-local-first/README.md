# OpenJarvis Protocol Specifications

Padrões de comunicação via MCP (Model Context Protocol) e JSON-RPC local.
