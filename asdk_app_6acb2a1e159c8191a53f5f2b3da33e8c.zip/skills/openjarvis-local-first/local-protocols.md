# Protocolos de Comunicação Local

1. Chamadas locais autenticadas via Bearer Token e HMAC SHA-256.
2. Persistência em arquivo JSON estruturado atômico com .tmp swap.
