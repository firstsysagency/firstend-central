---
name: openjarvis-local-first
description: "Arquitetura local-first para execução de tarefas autônomas com privacidade de dados e failover resiliente."
---

# OpenJarvis: Agentes Local-First

## Visão Geral
Habilita agentes autônomos que priorizam a execução em nós locais ou em infraestrutura privada (VPS Firstsys), garantindo que dados confidenciais e credenciais nunca trafeguem por serviços externos desnecessários.

## Pilares
1. **Privacidade Absoluta:** Vetores e dados em repouso cifrados.
2. **Resiliência Offline:** Suporte a cache local com failover gracioso.
3. **Auditoria Criptográfica:** Toda transação assina um log SHA-256.
