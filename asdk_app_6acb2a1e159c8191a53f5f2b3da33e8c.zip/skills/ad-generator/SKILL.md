---
name: ad-generator
description: "Gerador automatizado de anúncios de alta conversão estruturados em 40 templates validados de grandes marcas globais, integrando foto do produto, identidade e copy persuasiva."
---

# Ad Generator (40 Proven Brand Templates)

## Objetivo
Estruturar rapidamente criativos publicitários para redes sociais (Instagram, TikTok, Meta Ads, Google Display) combinando fotos do produto com 40 frameworks de design comprovados de grandes marcas (Apple, Nike, Spotify, Glossier, Gymshark).

## Comando de Ativação
- `/ad-generator`: Inicia a consultoria e geração de criativos a partir de imagem do produto ou briefing de marca.

## Framework dos 40 Templates
Os templates cobrem as principais alavancas de conversão:
1. **Split Benefit:** Divisão meio a meio destacando o problema à esquerda e a solução à direita.
2. **Feature Teardown:** Linhas indicativas conectando benefícios específicos aos pontos da foto do produto.
3. **Social Proof Grid:** Depoimentos de 5 estrelas em cards flutuantes sobrepostos ao produto em uso.
4. **Bold Minimalist Typography:** Tipografia pesada de contraste com uma única frase de gancho e hero shot isolado.
5. **Before & After Real-Life:** Demonstração visual do impacto tangível com selo de garantia.
6. **Comparison Matrix:** Tabela comparativa clara "Nós vs Outros" com checks verdes e cruzes vermelhas.

## Regras de Composição Visual
- Proporção: Quadrado (1:1), Stories/Reels (9:16) ou Paisagem (16:9).
- Título principal limitado a no máximo 6 palavras de alto impacto.
- Botão ou indicação de Call to Action (CTA) em posição de leitura natural inferior.
