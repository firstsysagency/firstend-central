# Checklist do Criativo
- [ ] A proposta de valor é legível em menos de 3 segundos em tela de celular?
- [ ] O produto está nítido e em destaque com bom recorte de fundo?
- [ ] A hierarquia tipográfica guia o olho diretamente para a ação principal?
- [ ] A paleta de cores respeita o manual de identidade da marca?
