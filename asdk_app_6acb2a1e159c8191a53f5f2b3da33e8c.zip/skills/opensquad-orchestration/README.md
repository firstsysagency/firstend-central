# OpenSquad Architecture Guide

Arquitetura distribuída para agentes que colaboram em squads temáticos:
- Squad de Vendas (SDR + Closer + Onboarding)
- Squad de Engenharia (Coder + Reviewer + QA Tester)
- Squad de Suporte (Triador + Nível 2 + Financeiro)
