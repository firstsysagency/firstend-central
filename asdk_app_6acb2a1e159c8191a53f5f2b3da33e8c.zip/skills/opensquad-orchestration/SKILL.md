---
name: opensquad-orchestration
description: "Padrões de decomposição de tarefas complexas entre agentes especializados com handoff explícito e supervisão central."
---

# OpenSquad: Orquestração Multiagente

## Princípios Arquiteturais
- **Divisão de Responsabilidades:** Cada agente tem apenas uma persona e responsabilidade bem delimitada (ex: Pesquisador, Redator, Auditor, Executor).
- **Handoff Transparente:** O repasse de contexto entre agentes é feito via payloads JSON imutáveis com histórico de decisões.
- **Supervisão do Orquestrador:** Um agente líder avalia a qualidade da entrega antes de retornar a resposta final ao usuário.
