# Workflow: UGC de 15 Segundos
1. **Passo 1:** Escolha o arquétipo do criador (Estudante cansado, Especialista cético, Amiga sincera, Empreendedor acelerado).
2. **Passo 2:** Defina o gancho inicial com alta retenção.
3. **Passo 3:** Gere o script com marcações de pausas `[pausa]`, respiração e expressões `[sorriso sutil]`.
4. **Passo 4:** Gere os prompts de avatar para HeyGen / Kling / Hedra.
