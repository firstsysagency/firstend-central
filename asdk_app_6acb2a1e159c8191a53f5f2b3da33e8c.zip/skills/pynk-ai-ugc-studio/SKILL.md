---
name: pynk-ai-ugc-studio
description: "Criação de anúncios em vídeo UGC de 15 segundos para redes sociais com influenciadores virtuais hiper-realistas, ganchos magnéticos e linguagem humana espontânea."
---

# PYNK AI UGC Studio (15s Hyper-Realistic Ads)

## Objetivo
Gerar scripts e prompts completos para anúncios em formato UGC (User Generated Content) de 15 segundos no TikTok, Reels e Shorts, utilizando avatares e vozes de IA com espontaneidade, gírias leves, pausas de respiração e autenticidade de vídeo de smartphone.

## Comando de Ativação
- `/ugc`: Gera o roteiro de 15 segundos e a persona do criador de conteúdo.

## Estrutura do Roteiro de 15 Segundos
- **0 a 3s - O Gancho (Hook):** Quebra de padrão visual e verbal imediata. Ex: *"Se você ainda usa X em 2026, você tá perdendo tempo..."* ou *"Nem meu dermatologista acreditou nisso..."*.
- **3 a 8s - A Revelação do Problema e Teste:** Mostra o produto na mão com a câmera frontal do celular levemente instável e iluminação de janela.
- **8 a 12s - Prova e Sensação:** Textura, aplicação e resultado palpável na pele/tela/ambiente.
- **12 a 15s - CTA Natural:** Sem parecer vendedor agressivo: *"O link tá aqui embaixo antes que acabe o lote"*.

## Prompts para Câmera Frontal e Lip-Sync
- Enquadramento vertical `9:16`.
- Expressões faciais orgânicas (sobrancelha levantada, sorriso casual, pausas naturais com *"tipo assim"*).
