# Checklist de Autenticidade UGC
- [ ] O roteiro dura exatamente entre 13 e 15 segundos quando lido em ritmo normal?
- [ ] O tom soa como uma mensagem enviada a um amigo no WhatsApp?
- [ ] O produto aparece em cena antes do segundo 04?
- [ ] Há chamada clara para ação nos últimos 3 segundos?
