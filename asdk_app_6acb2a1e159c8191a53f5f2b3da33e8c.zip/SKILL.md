---
name: asdk_app_6acb2a1e159c8191a53f5f2b3da33e8c
description: "MCP da Firstsys — CRM Zatten WhatsApp e Coleção de Skills Operacionais de IA"
---

# Firstsys MCP

Pacote oficial de ferramentas MCP e Skills operacionais para agentes de IA e ChatGPT.
