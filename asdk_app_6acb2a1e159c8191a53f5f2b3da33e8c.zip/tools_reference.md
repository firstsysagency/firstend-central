# Catálogo de Ferramentas MCP — Firstsys Zatten Central & Skills (Total: 84 ferramentas)

### `firstsys_get_profile`
- **Título:** Consultar Perfil Firstsys
- **Descrição:** Retorna o identificador opaco permanente, organização e papéis da conta Firstsys autenticada.

### `zatten_list_connections`
- **Título:** Listar Conexões Zatten
- **Descrição:** Lista as conexões Zatten ativas autorizadas para a organização do usuário.

### `zatten_get_connection_status`
- **Título:** Consultar Status da Conexão Zatten
- **Descrição:** Consulta o status de integridade e prontidão operacional de uma conexão Zatten específica.

### `zatten_kanban_get`
- **Título:** Buscar Colunas do Kanban Zatten
- **Descrição:** Busca informações de todas as colunas do Kanban de atendimento no CRM Zatten.

### `zatten_tags_get`
- **Título:** Buscar Tags Cadastradas Zatten
- **Descrição:** Busca informações de todas as tags disponíveis cadastradas no CRM Zatten.

### `zatten_leads_leadnumber_get`
- **Título:** Obter Detalhes do Lead por Telefone
- **Descrição:** Obtém detalhes cadastrais e informações completas de um lead específico pelo número de telefone (WaId).

### `zatten_leads_leadnumber_notes_patch`
- **Título:** Atualizar Anotações do Lead
- **Descrição:** Atualiza ou adiciona anotações no perfil de um lead no CRM Zatten. Modifica dados no CRM.

### `zatten_leads_leadnumber_properties_patch`
- **Título:** Atualizar Propriedades Customizadas do Lead
- **Descrição:** Atualiza propriedades customizadas de um lead a partir do slug da propriedade. Modifica dados no CRM.

### `zatten_leads_leadnumber_threads_get`
- **Título:** Listar Threads de Conversa do Lead
- **Descrição:** Lista todas as threads de conversa vinculadas a um lead específico.

### `zatten_leads_leadnumber_kanban_patch`
- **Título:** Mover Lead no Kanban
- **Descrição:** Move um lead entre colunas do Kanban de atendimento. Modifica o status no CRM.

### `zatten_leads_leadnumber_assignee_patch`
- **Título:** Atualizar Responsável e Departamento do Lead
- **Descrição:** Atualiza o responsável (atendente e departamento) de um lead. Exige department_id. Aceita user_email ou user_id; se omitido, executa o rodízio do departamento. Modifica atribuição no CRM.

### `zatten_leads_leadnumber_toggle_attendant_response_post`
- **Título:** Alternar ou Pausar Atendente de IA do Lead
- **Descrição:** Ativa ou desativa a resposta automática do atendente de IA para um lead. Quando enabled for false, aceita pause_minutes (1 a 10.080 minutos) para pausa temporária. Modifica automação no CRM.

### `zatten_leads_leadnumber_tag_post`
- **Título:** Adicionar Tag ao Lead
- **Descrição:** Adiciona uma tag específica a um lead no CRM Zatten. Modifica tags no CRM.

### `zatten_leads_leadnumber_tag_delete`
- **Título:** Remover Tag do Lead
- **Descrição:** Remove uma tag de um lead no CRM Zatten. Modifica tags no CRM.

### `zatten_properties_get`
- **Título:** Listar Propriedades Personalizadas do Projeto
- **Descrição:** Lista as propriedades personalizadas cadastradas no projeto (slug, name, description, is_enum) para consulta prévia.

### `zatten_properties_slug_values_get`
- **Título:** Listar Valores Permitidos de Propriedade Enum
- **Descrição:** Retorna valores válidos e descrições de propriedades configuradas como lista/enum. Para campos de texto livre, retorna mensagem informativa.

### `zatten_leads_leadnumber_notification_post`
- **Título:** Notificar Responsável Atual do Lead
- **Descrição:** Envia notificação push interna ao atendente responsável atual pelo lead no CRM Zatten. Retorna se a notificação foi aceita ou se não há atendente com acesso.

### `zatten_automations_trigger_post`
- **Título:** Disparar Automações Compatíveis com o Lead
- **Descrição:** Solicita que a Zatten agende/dispare automações compatíveis com o estado atual do lead. Sucesso na solicitação não garante que uma automação era aplicável nem execução instantânea.

### `zatten_flows_trigger_post`
- **Título:** Disparar Trigger Flow
- **Descrição:** Dispara um Trigger Flow existente para um lead com suporte a chave de idempotência. Status HTTP 202 indica recebimento e despacho assíncrono.

### `zatten_hooks_path_post`
- **Título:** Disparar Webhook de Entrada Configurado
- **Descrição:** Dispara um Trigger Flow configurado como webhook de entrada na Zatten encaminhando payload JSON. HTTP 202 confirma recebimento sem garantir que um flow coincidiu com o path.

### `zatten_agent_config_get`
- **Título:** Ler Configuração Completa do Agente (Sanitizada)
- **Descrição:** Lê o template e configuração do agente Zatten (prompt, modelo, skills, tools, automações, revision) com todos os segredos e credenciais removidos via <redacted>.

### `zatten_agent_config_update`
- **Título:** Atualizar Configuração do Agente (Rascunho Seguro)
- **Descrição:** Atualiza blocos do template do agente com concorrência por expected_revision e retenção de segredos. Gera apenas rascunho sem publicação automática.

### `zatten_messages_text_post`
- **Título:** Enviar Mensagem de Texto WhatsApp
- **Descrição:** Envia uma mensagem de texto simples para um lead no WhatsApp via API Zatten. Altera conversas no CRM.

### `zatten_send_message`
- **Título:** Disparar Mensagem Zatten (Confirmação Humana)
- **Descrição:** Dispara uma mensagem para um contato via API Zatten. AÇÃO DE ESCRITA: EXIGE CONFIRMAÇÃO DO USUÁRIO.

### `zatten_messages_template_post`
- **Título:** Enviar Mensagem de Template HSM
- **Descrição:** Envia uma mensagem de template HSM pré-aprovado para um lead no WhatsApp. Altera conversas no CRM.

### `zatten_messages_audio_post`
- **Título:** Enviar Mensagem de Áudio WhatsApp
- **Descrição:** Envia uma mensagem de áudio para um lead no WhatsApp via API Zatten.

### `zatten_messages_image_post`
- **Título:** Enviar Mensagem de Imagem WhatsApp
- **Descrição:** Envia uma mensagem de imagem com legenda opcional para um lead via API Zatten.

### `zatten_messages_file_post`
- **Título:** Enviar Documento ou Arquivo WhatsApp
- **Descrição:** Envia um arquivo ou documento (PDF, DOCX) para um lead no WhatsApp.

### `zatten_messages_video_post`
- **Título:** Enviar Mensagem de Vídeo WhatsApp
- **Descrição:** Envia uma mensagem de vídeo com legenda opcional para um lead via API Zatten.

### `zatten_messages_history_get`
- **Título:** Buscar Histórico de Mensagens do Lead
- **Descrição:** Busca o histórico completo de mensagens de um lead com suporte a formatação LLM.

### `zatten_attendants_list`
- **Título:** Listar Atendentes e Departamentos Ativos
- **Descrição:** Obtém a lista de atendentes ativos cadastrados na Zatten (com e-mail, ID e departamento) para uso na atribuição de responsáveis via zatten_leads_leadnumber_assignee_patch.

### `zatten_templates_list`
- **Título:** Listar Templates HSM Aprovados
- **Descrição:** Consulta a lista de templates HSM aprovados pela Meta WhatsApp Business API disponíveis para envio através de zatten_messages_template_post.

### `zatten_users_get`
- **Título:** Consultar Usuários e Atendentes Ativos
- **Descrição:** Consulta a lista de todos os usuários e atendentes ativos cadastrados no CRM Zatten com ID, e-mail e departamentos para atribuição de responsável via zatten_leads_leadnumber_assignee_patch.

### `zatten_templates_get`
- **Título:** Consultar Templates HSM Aprovados
- **Descrição:** Consulta os templates HSM oficiais cadastrados e aprovados pela Meta WhatsApp Business API disponíveis para envio através de zatten_messages_template_post.

### `firstsys_skills_list`
- **Título:** Listar Skills de IA da Central
- **Descrição:** Lista todas as skills, diretrizes operacionais e especialidades de IA cadastradas na Central Firstsys.

### `firstsys_skills_get`
- **Título:** Obter Detalhes e Arquivos da Skill (SKILL.md)
- **Descrição:** Retorna a especificação completa, metadados e arquivos de uma skill para que a IA possa assimilar suas instruções e operar em alto nível.

### `firstsys_skills_create`
- **Título:** Criar Nova Skill de IA
- **Descrição:** Cria uma nova skill de IA na Central Firstsys com instruções e metadados operacionais.

### `firstsys_skills_update`
- **Título:** Atualizar Metadados da Skill
- **Descrição:** Atualiza o nome, descrição, categoria, tags ou versão de uma skill existente.

### `firstsys_skills_delete`
- **Título:** Excluir Skill da Biblioteca
- **Descrição:** Remove uma skill da biblioteca. Exige confirmação explícita com confirm: true.

### `firstsys_skills_install`
- **Título:** Instalar Skill em Contexto
- **Descrição:** Instala e vincula uma skill a um contexto específico (agente, conexão Zatten, projeto ou MCP).

### `firstsys_skills_uninstall`
- **Título:** Desinstalar Skill de Contexto
- **Descrição:** Desvincula e desinstala uma skill de um contexto operacional (agente, conexão ou projeto).

### `firstsys_skills_installations_list`
- **Título:** Listar Instalações da Skill por Contexto
- **Descrição:** Lista todas as vinculações ativas da skill por agente, projeto, conexão ou ambiente.

### `firstsys_skills_installations_create`
- **Título:** Criar Instalação de Skill em Contexto
- **Descrição:** Vincula granularmente uma skill a um agente, projeto, MCP ou conexão com versão fixada opcional.

### `firstsys_skills_installations_delete`
- **Título:** Remover Instalação de Skill de Contexto
- **Descrição:** Remove o registro de instalação de uma skill em um contexto específico.

### `firstsys_skill_files_list`
- **Título:** Listar Arquivos da Skill
- **Descrição:** Lista todos os arquivos em árvore de uma skill com hashes SHA-256 e tamanhos.

### `firstsys_skill_files_get`
- **Título:** Obter Arquivo da Skill
- **Descrição:** Lê o conteúdo textual de um arquivo específico de uma skill.

### `firstsys_skill_files_save`
- **Título:** Salvar Arquivo na Skill (Criar ou Atualizar)
- **Descrição:** Cria ou atualiza um arquivo textual dentro da pasta lógica da skill com validação de segurança e hash SHA-256.

### `firstsys_skill_files_create`
- **Título:** Criar Arquivo na Skill
- **Descrição:** Cria um novo arquivo textual dentro da pasta lógica da skill com validação de segurança.

### `firstsys_skill_files_update`
- **Título:** Atualizar Arquivo na Skill
- **Descrição:** Atualiza o conteúdo de um arquivo existente e gera novo hash SHA-256.

### `firstsys_skill_files_delete`
- **Título:** Excluir Arquivo da Skill
- **Descrição:** Exclui um arquivo da skill (SKILL.md não pode ser excluído).

### `firstsys_skill_files_restore`
- **Título:** Restaurar Arquivo Excluído
- **Descrição:** Restaura um arquivo que foi movido para a lixeira (soft delete).

### `firstsys_skills_import_inspect`
- **Título:** Inspecionar Repositório Git (Anti-SSRF & Secret Scanning)
- **Descrição:** Analisa e audita um repositório Git público antes de importar, verificando licenças, estrutura e possíveis segredos.

### `firstsys_skills_import_preview`
- **Título:** Visualizar Repositório Git para Importação
- **Descrição:** Inspeciona um repositório público GitHub/GitLab com proteção anti-SSRF e secret scanning antes de importar.

### `firstsys_skills_import_commit`
- **Título:** Efetivar Importação de Repositório Git
- **Descrição:** Efetiva a importação dos arquivos selecionados do repositório Git auditado, criando a nova skill versionada.

### `firstsys_skills_import_from_git`
- **Título:** Importar Skill de Repositório Git
- **Descrição:** Importa arquivos selecionados de um repositório Git auditado criando um snapshot versionado.

### `firstsys_skills_import_status`
- **Título:** Consultar Status de Origem Git da Skill
- **Descrição:** Consulta informações de rastreabilidade Git da skill (URL, branch, commit SHA e data de sincronização).

### `firstsys_skills_sync_preview`
- **Título:** Comparar Atualizações do Repositório Git
- **Descrição:** Compara a versão local da skill com a versão mais recente do branch remoto do Git.

### `firstsys_skills_sync_inspect`
- **Título:** Inspecionar Atualizações do Repositório Git (Alias)
- **Descrição:** Inspeciona e compara o commit SHA e arquivos entre a versão local e a remota no Git.

### `firstsys_skills_sync_from_git`
- **Título:** Sincronizar Atualizações do Git
- **Descrição:** Aplica atualizações do repositório remoto Git sob confirmação explícita sem sobrescrever arquivos locais.

### `firstsys_skills_sync_commit`
- **Título:** Confirmar Sincronização do Git (Alias)
- **Descrição:** Aplica e commita as atualizações do branch Git para a skill sob confirmação.

### `firstsys_skills_versions_list`
- **Título:** Listar Versões da Skill
- **Descrição:** Consulta o histórico imutável de versões e snapshots SHA-256 de uma skill.

### `firstsys_skills_versions_get`
- **Título:** Obter Detalhes da Versão
- **Descrição:** Recupera o snapshot de arquivos de uma versão semântica específica da skill.

### `firstsys_skills_versions_create`
- **Título:** Criar Snapshot de Versão da Skill
- **Descrição:** Cria uma nova versão semântica imutável com changelog e snapshot criptográfico SHA-256 dos arquivos.

### `firstsys_skills_versions_compare`
- **Título:** Comparar (Diff) Versões da Skill
- **Descrição:** Compara arquivos adicionados, modificados e removidos entre duas versões da skill.

### `firstsys_skills_versions_diff`
- **Título:** Diff entre Versões da Skill (Alias)
- **Descrição:** Gera relatório de diff estrutural entre duas versões da skill.

### `firstsys_skills_versions_restore`
- **Título:** Restaurar Versão Anterior (Rollback)
- **Descrição:** Restaura a skill para um snapshot anterior com confirmação explícita.

### `firstsys_skills_versions_rollback`
- **Título:** Rollback de Versão da Skill (Alias)
- **Descrição:** Reverte o estado de arquivos e instruções da skill para uma versão semântica anterior.

### `firstsys_skills_audit_list`
- **Título:** Consultar Trilha de Auditoria da Skill
- **Descrição:** Consulta o histórico cronológico de criações, edições, instalações e importações da skill.

### `firstsys_skills_dependencies_list`
- **Título:** Listar Dependências da Skill
- **Descrição:** Retorna a lista de pacotes, módulos e ferramentas necessários para o funcionamento da skill.

### `firstsys_skills_permissions_get`
- **Título:** Consultar Permissões Requeridas da Skill
- **Descrição:** Retorna os privilégios e permissões necessários para a skill operar.

### `firstsys_skills_permissions_update`
- **Título:** Atualizar Permissões da Skill
- **Descrição:** Atualiza o rol de permissões autorizadas para a skill.

### `firstsys_security_list`
- **Título:** Listar Tecnologias e Métodos de Segurança
- **Descrição:** Lista padrões, métodos, diretrizes e checklists de segurança corporativa Firstsys para projetos de software e IA.

### `firstsys_security_get`
- **Título:** Consultar Método de Segurança
- **Descrição:** Retorna a especificação completa de segurança, checklists, regras técnicas, conformidade e arquivos vinculados.

### `firstsys_security_create`
- **Título:** Cadastrar Tecnologia de Segurança
- **Descrição:** Cadastra um novo método, diretriz técnica ou padrão de segurança corporativa com arquivos e normas de conformidade.

### `firstsys_security_update`
- **Título:** Atualizar Método de Segurança
- **Descrição:** Atualiza metadados, categoria, nível de severidade ou normas de conformidade de uma diretriz de segurança.

### `firstsys_security_delete`
- **Título:** Excluir Método de Segurança
- **Descrição:** Arquiva ou remove permanentemente um padrão de segurança do catálogo corporativo.

### `firstsys_security_tag_add`
- **Título:** Adicionar Tag ao Item de Segurança
- **Descrição:** Adiciona uma tag dinâmica a uma tecnologia ou diretriz de segurança para categorização livre.

### `firstsys_security_tag_remove`
- **Título:** Remover Tag do Item de Segurança
- **Descrição:** Remove uma tag de uma tecnologia ou diretriz de segurança.

### `firstsys_security_files_list`
- **Título:** Listar Arquivos de Segurança
- **Descrição:** Lista todos os arquivos técnicos (SECURITY.md, rules.json, checklist.md) vinculados ao método de segurança.

### `firstsys_security_files_get`
- **Título:** Obter Arquivo de Segurança
- **Descrição:** Lê o conteúdo textual de um arquivo específico de uma diretriz de segurança (ex: checklist.md, rules.json).

### `firstsys_security_files_save`
- **Título:** Salvar Arquivo de Segurança
- **Descrição:** Cria ou atualiza um arquivo textual na pasta da diretriz de segurança com validação estrita anti-traversal e hash SHA-256.

### `firstsys_security_files_delete`
- **Título:** Excluir Arquivo de Segurança
- **Descrição:** Exclui um arquivo da pasta de segurança (SECURITY.md mestre é protegido contra exclusão).

### `firstsys_security_files_restore`
- **Título:** Restaurar Arquivo de Segurança
- **Descrição:** Restaura um arquivo da diretriz de segurança que foi movido para a lixeira.

### `firstsys_security_audit_list`
- **Título:** Consultar Auditoria de Segurança
- **Descrição:** Consulta o histórico cronológico de criações, edições e alterações nos métodos e arquivos de segurança.

