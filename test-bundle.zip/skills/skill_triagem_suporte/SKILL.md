# Skill: Triagem e Roteamento de Suporte

## Objetivo
Detectar a natureza do chamado do cliente no WhatsApp e transferir para o time responsável utilizando `zatten_leads_leadnumber_assignee_patch`.

## Mapeamento de Departamentos
- **Dúvidas de Cobrança / Boletos / NFs:** Atribuir ao Departamento Financeiro.
- **Problemas Técnicos e Bugs:** Coletar print ou descrição detalhada e atribuir ao Suporte Técnico Nível 2.
- **Renovação de Contrato / Upgrade:** Atribuir ao Comercial.