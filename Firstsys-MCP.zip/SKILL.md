---
name: firstsys-mcp
description: "MCP da Firstsys — CRM Zatten WhatsApp e Coleção de Skills Operacionais de IA"
---

# Firstsys MCP

Pacote oficial de ferramentas MCP e Skills operacionais para agentes de IA e ChatGPT.
