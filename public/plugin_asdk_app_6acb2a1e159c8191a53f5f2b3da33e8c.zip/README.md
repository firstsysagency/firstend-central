# Pacote Oficial MCP Firstsys Zatten Central & Skills

Este pacote reúne todas as especificações e instruções necessárias para conectar o **ChatGPT** ao servidor remoto MCP da **Central Firstsys** e ao CRM **Zatten WhatsApp**.

---

## Conteúdo do Pacote
1. `.codex-plugin/plugin.json`: Manifesto de Plugin OpenAI / Codex com bloco `interface` obrigatório.
2. `.agent-plugin/plugin.json`: Manifesto de Agente OpenAI.
3. `.claude-plugin/plugin.json`: Manifesto para Claude e clientes MCP.
4. `.mcp.json`: Configuração de servidor MCP remoto.
5. `.app.json`: Configuração de aplicativo OpenAI com vínculo ao `asdk_app_6acb2a1e159c8191a53f5f2b3da33e8c`.
6. `skills/*/SKILL.md`: Coleção de Skills e instruções operacionais da Central Firstsys com YAML frontmatter.
7. `security/*/SECURITY.md`: Coleção de diretrizes explicativas e padrões técnicos de segurança corporativa.
8. Controles de Segurança Corporativa: 100 controles independentes (SEC-001 a SEC-100) com 15 ferramentas MCP dedicadas.
9. `openapi.json`: Especificação OpenAPI 3.1.0 completa das ferramentas.
10. `instructions.md`: Prompt mestre de diretrizes operacionais.
11. `tools_reference.md`: Guia resumido de cada ferramenta disponível.
