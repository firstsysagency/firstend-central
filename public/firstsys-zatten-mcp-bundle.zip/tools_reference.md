# Catálogo de Ferramentas MCP — Firstsys Zatten Central & Skills (Total: 40 ferramentas)

## Identidade & Conexões

### `firstsys_get_profile`
- **Título:** Consultar Perfil Firstsys
- **Descrição:** Retorna o identificador opaco permanente, organização e papéis da conta Firstsys autenticada.
- **Parâmetros:** Nenhum (requisição sem corpo)

### `zatten_list_connections`
- **Título:** Listar Conexões Zatten
- **Descrição:** Lista as conexões Zatten ativas autorizadas para a organização do usuário.
- **Parâmetros:** Nenhum (requisição sem corpo)

### `zatten_get_connection_status`
- **Título:** Consultar Status da Conexão Zatten
- **Descrição:** Consulta o status de integridade e prontidão operacional de uma conexão Zatten específica.
- **Parâmetros:** `connectionId`

## CRM, Leads & Kanban

### `zatten_leads_leadnumber_get`
- **Título:** Obter Detalhes do Lead por Telefone
- **Descrição:** Obtém detalhes cadastrais e informações completas de um lead específico pelo número de telefone (WaId).
- **Parâmetros:** `leadNumber`, `lead_number`, `connectionId`, `connection_id`

### `zatten_kanban_get`
- **Título:** Buscar Colunas do Kanban Zatten
- **Descrição:** Busca informações de todas as colunas do Kanban de atendimento no CRM Zatten.
- **Parâmetros:** `connectionId`, `connection_id`

### `zatten_leads_leadnumber_kanban_patch`
- **Título:** Mover Lead no Kanban
- **Descrição:** Move um lead entre colunas do Kanban de atendimento. Modifica o status no CRM.
- **Parâmetros:** `leadNumber`, `lead_number`, `column_id`, `connectionId`, `connection_id`

### `zatten_leads_leadnumber_notes_patch`
- **Título:** Atualizar Anotações do Lead
- **Descrição:** Atualiza ou adiciona anotações no perfil de um lead no CRM Zatten. Modifica dados no CRM.
- **Parâmetros:** `leadNumber`, `lead_number`, `note`, `delete_previous_note`, `connectionId`, `connection_id`

### `zatten_leads_leadnumber_properties_patch`
- **Título:** Atualizar Propriedades Customizadas do Lead
- **Descrição:** Atualiza propriedades customizadas de um lead a partir do slug da propriedade. Modifica dados no CRM.
- **Parâmetros:** `leadNumber`, `lead_number`, `property`, `value`, `connectionId`, `connection_id`

### `zatten_properties_get`
- **Título:** Listar Propriedades Personalizadas do Projeto
- **Descrição:** Lista as propriedades personalizadas cadastradas no projeto (slug, name, description, is_enum) para consulta prévia.
- **Parâmetros:** `connection_id`, `connectionId`

### `zatten_properties_slug_values_get`
- **Título:** Listar Valores Permitidos de Propriedade Enum
- **Descrição:** Retorna valores válidos e descrições de propriedades configuradas como lista/enum. Para campos de texto livre, retorna mensagem informativa.
- **Parâmetros:** `property_slug`, `connection_id`, `connectionId`

### `zatten_tags_get`
- **Título:** Buscar Tags Cadastradas Zatten
- **Descrição:** Busca informações de todas as tags disponíveis cadastradas no CRM Zatten.
- **Parâmetros:** `connectionId`, `connection_id`

### `zatten_leads_leadnumber_tag_post`
- **Título:** Adicionar Tag ao Lead
- **Descrição:** Adiciona uma tag específica a um lead no CRM Zatten. Modifica tags no CRM.
- **Parâmetros:** `leadNumber`, `lead_number`, `tag_id`, `connectionId`, `connection_id`

### `zatten_leads_leadnumber_tag_delete`
- **Título:** Remover Tag do Lead
- **Descrição:** Remove uma tag de um lead no CRM Zatten. Modifica tags no CRM.
- **Parâmetros:** `leadNumber`, `lead_number`, `tag_id`, `connectionId`, `connection_id`

### `zatten_leads_leadnumber_threads_get`
- **Título:** Listar Threads de Conversa do Lead
- **Descrição:** Lista todas as threads de conversa vinculadas a um lead específico.
- **Parâmetros:** `leadNumber`, `lead_number`, `connectionId`, `connection_id`

## Equipe & Atribuição

### `zatten_users_get`
- **Título:** Consultar Usuários e Atendentes Ativos
- **Descrição:** Consulta a lista de todos os usuários e atendentes ativos cadastrados no CRM Zatten com ID, e-mail e departamentos para atribuição de responsável via zatten_leads_leadnumber_assignee_patch.
- **Parâmetros:** `connectionId`, `connection_id`

### `zatten_attendants_list`
- **Título:** Listar Atendentes e Departamentos Ativos
- **Descrição:** Obtém a lista de atendentes ativos cadastrados na Zatten (com e-mail, ID e departamento) para uso na atribuição de responsáveis via zatten_leads_leadnumber_assignee_patch.
- **Parâmetros:** `connectionId`, `connection_id`

### `zatten_leads_leadnumber_assignee_patch`
- **Título:** Atualizar Responsável e Departamento do Lead
- **Descrição:** Atualiza o responsável (atendente e departamento) de um lead. Exige department_id. Aceita user_email ou user_id; se omitido, executa o rodízio do departamento. Modifica atribuição no CRM.
- **Parâmetros:** `lead_number`, `leadNumber`, `department_id`, `user_email`, `user_id`, `connection_id`, `connectionId`

### `zatten_leads_leadnumber_notification_post`
- **Título:** Notificar Responsável Atual do Lead
- **Descrição:** Envia notificação push interna ao atendente responsável atual pelo lead no CRM Zatten. Retorna se a notificação foi aceita ou se não há atendente com acesso.
- **Parâmetros:** `lead_number`, `leadNumber`, `title`, `body`, `connection_id`, `connectionId`

### `zatten_leads_leadnumber_toggle_attendant_response_post`
- **Título:** Alternar ou Pausar Atendente de IA do Lead
- **Descrição:** Ativa ou desativa a resposta automática do atendente de IA para um lead. Quando enabled for false, aceita pause_minutes (1 a 10.080 minutos) para pausa temporária. Modifica automação no CRM.
- **Parâmetros:** `lead_number`, `leadNumber`, `enabled`, `pause_minutes`, `connection_id`, `connectionId`

## Mensagens & Templates WhatsApp

### `zatten_messages_text_post`
- **Título:** Enviar Mensagem de Texto WhatsApp
- **Descrição:** Envia uma mensagem de texto simples para um lead no WhatsApp via API Zatten. Altera conversas no CRM.
- **Parâmetros:** `lead_number`, `message`, `name`, `connectionId`, `connection_id`

### `zatten_send_message`
- **Título:** Disparar Mensagem Zatten (Confirmação Humana)
- **Descrição:** Dispara uma mensagem para um contato via API Zatten. AÇÃO DE ESCRITA: EXIGE CONFIRMAÇÃO DO USUÁRIO.
- **Parâmetros:** `recipient`, `message`, `connectionId`, `connection_id`

### `zatten_messages_history_get`
- **Título:** Buscar Histórico de Mensagens do Lead
- **Descrição:** Busca o histórico completo de mensagens de um lead com suporte a formatação LLM.
- **Parâmetros:** `leadNumber`, `lead_number`, `thread_id`, `llm_format`, `connectionId`, `connection_id`

### `zatten_templates_get`
- **Título:** Consultar Templates HSM Aprovados
- **Descrição:** Consulta os templates HSM oficiais cadastrados e aprovados pela Meta WhatsApp Business API disponíveis para envio através de zatten_messages_template_post.
- **Parâmetros:** `connectionId`, `connection_id`

### `zatten_templates_list`
- **Título:** Listar Templates HSM Aprovados
- **Descrição:** Consulta a lista de templates HSM aprovados pela Meta WhatsApp Business API disponíveis para envio através de zatten_messages_template_post.
- **Parâmetros:** `connectionId`, `connection_id`

### `zatten_messages_template_post`
- **Título:** Enviar Mensagem de Template HSM
- **Descrição:** Envia uma mensagem de template HSM pré-aprovado para um lead no WhatsApp. Altera conversas no CRM.
- **Parâmetros:** `lead_number`, `template_name`, `name`, `connectionId`, `connection_id`

### `zatten_messages_image_post`
- **Título:** Enviar Mensagem de Imagem WhatsApp
- **Descrição:** Envia uma mensagem de imagem com legenda opcional para um lead via API Zatten.
- **Parâmetros:** `lead_number`, `image_url`, `caption`, `connectionId`, `connection_id`

### `zatten_messages_audio_post`
- **Título:** Enviar Mensagem de Áudio WhatsApp
- **Descrição:** Envia uma mensagem de áudio para um lead no WhatsApp via API Zatten.
- **Parâmetros:** `lead_number`, `audio_url`, `connectionId`, `connection_id`

### `zatten_messages_video_post`
- **Título:** Enviar Mensagem de Vídeo WhatsApp
- **Descrição:** Envia uma mensagem de vídeo com legenda opcional para um lead via API Zatten.
- **Parâmetros:** `lead_number`, `video_url`, `caption`, `connectionId`, `connection_id`

### `zatten_messages_file_post`
- **Título:** Enviar Documento ou Arquivo WhatsApp
- **Descrição:** Envia um arquivo ou documento (PDF, DOCX) para um lead no WhatsApp.
- **Parâmetros:** `lead_number`, `file_url`, `file_name`, `connectionId`, `connection_id`

## Automações, Flows & Agente

### `zatten_automations_trigger_post`
- **Título:** Disparar Automações Compatíveis com o Lead
- **Descrição:** Solicita que a Zatten agende/dispare automações compatíveis com o estado atual do lead. Sucesso na solicitação não garante que uma automação era aplicável nem execução instantânea.
- **Parâmetros:** `lead_id`, `connection_id`, `connectionId`

### `zatten_flows_trigger_post`
- **Título:** Disparar Trigger Flow
- **Descrição:** Dispara um Trigger Flow existente para um lead com suporte a chave de idempotência. Status HTTP 202 indica recebimento e despacho assíncrono.
- **Parâmetros:** `trigger_type`, `lead_number`, `leadNumber`, `lead_id`, `trigger_event`, `idempotency_key`, `connection_id`, `connectionId`

### `zatten_hooks_path_post`
- **Título:** Disparar Webhook de Entrada Configurado
- **Descrição:** Dispara um Trigger Flow configurado como webhook de entrada na Zatten encaminhando payload JSON. HTTP 202 confirma recebimento sem garantir que um flow coincidiu com o path.
- **Parâmetros:** `path`, `lead_number`, `leadNumber`, `lead_id`, `payload`, `idempotency_key`, `connection_id`, `connectionId`

### `zatten_agent_config_get`
- **Título:** Ler Configuração Completa do Agente (Sanitizada)
- **Descrição:** Lê o template e configuração do agente Zatten (prompt, modelo, skills, tools, automações, revision) com todos os segredos e credenciais removidos via <redacted>.
- **Parâmetros:** `connection_id`, `connectionId`

### `zatten_agent_config_update`
- **Título:** Atualizar Configuração do Agente (Rascunho Seguro)
- **Descrição:** Atualiza blocos do template do agente com concorrência por expected_revision e retenção de segredos. Gera apenas rascunho sem publicação automática.
- **Parâmetros:** `expected_revision`, `template_patch`, `reason`, `connection_id`, `connectionId`

## Skills de IA

### `firstsys_skills_list`
- **Título:** Listar Skills de IA da Central
- **Descrição:** Lista todas as skills, diretrizes operacionais e especialidades de IA cadastradas na Central Firstsys.
- **Parâmetros:** `category`, `query`, `installed_only`

### `firstsys_skills_get`
- **Título:** Obter Detalhes e Arquivos da Skill (SKILL.md)
- **Descrição:** Retorna a especificação completa, metadados e arquivos (SKILL.md, regras) de uma skill para que a IA possa assimilar suas instruções e operar em alto nível.
- **Parâmetros:** `skill_id`

### `firstsys_skills_install`
- **Título:** Instalar ou Ativar Skill de IA
- **Descrição:** Instala ou ativa uma skill de IA para a conexão atual, habilitando o uso de suas regras e instruções.
- **Parâmetros:** `skill_id`, `install`

### `firstsys_skills_create`
- **Título:** Criar Nova Skill de IA
- **Descrição:** Cria uma nova skill de IA na Central Firstsys com instruções em SKILL.md e metadados operacionais.
- **Parâmetros:** `name`, `description`, `category`, `tags`, `skill_md_content`

### `firstsys_skills_update`
- **Título:** Atualizar Skill ou Arquivo SKILL.md
- **Descrição:** Atualiza o conteúdo do SKILL.md, nome ou descrição de uma skill existente na Central.
- **Parâmetros:** `skill_id`, `name`, `description`, `skill_md_content`

### `firstsys_skills_delete`
- **Título:** Excluir Skill de IA da Central
- **Descrição:** Remove permanentemente uma skill da Central. Exige confirmação explícita com confirm: true.
- **Parâmetros:** `skill_id`, `confirm`

