# Pacote Oficial MCP Firstsys Zatten Central & Skills

Este pacote reúne todas as especificações e instruções necessárias para conectar o **ChatGPT** ao servidor remoto MCP da **Central Firstsys** e ao CRM **Zatten WhatsApp**.

---

## Conteúdo do Pacote
1. `.codex-plugin/plugin.json`: Manifesto de Plugin OpenAI / Codex.
2. `.agent-plugin/plugin.json`: Manifesto de Agente OpenAI.
3. `.claude-plugin/plugin.json`: Manifesto para Claude e clientes MCP.
4. `.mcp.json`: Configuração de servidor MCP remoto.
5. `.app.json`: Configuração de aplicativo OpenAI.
6. `skills/*/SKILL.md`: Coleção de Skills e instruções operacionais da Central Firstsys.
7. `openapi.json`: Especificação OpenAPI 3.1.0 completa das 40 ferramentas.
8. `instructions.md`: Prompt mestre de diretrizes operacionais.
9. `tools_reference.md`: Guia resumido de cada ferramenta disponível.

---

## Como Importar no ChatGPT (Plugins / Custom GPT)
1. No modal **Enviar nova versão** de Plugins do ChatGPT, selecione o arquivo **firstsys-zatten-mcp-bundle.zip**.
2. O validador da OpenAI detectará automaticamente os arquivos de plugin (`.codex-plugin/plugin.json`, `.mcp.json`, `skills/*/SKILL.md`) e aprovará a publicação.
