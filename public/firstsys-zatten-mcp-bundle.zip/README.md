# Pacote Oficial MCP Firstsys Zatten Central & Skills

Este pacote reúne todas as especificações e instruções necessárias para conectar o **ChatGPT** ao servidor remoto MCP da **Central Firstsys** e ao CRM **Zatten WhatsApp**.

---

## Conteúdo do Pacote
1. `openapi.json`: Especificação OpenAPI 3.1.0 completa com todas as 40 ferramentas catalogadas e autenticação OAuth 2.1.
2. `mcp-manifest.json`: Manifesto de serviço MCP remoto padrão 2024-11-05.
3. `ai-plugin.json`: Manifesto de Action/Plugin da OpenAI.
4. `instructions.md`: Prompt mestre de diretrizes operacionais para colar nas instruções do Custom GPT.
5. `tools_reference.md`: Guia resumido de cada ferramenta disponível.

---

## Como Importar no ChatGPT (Custom GPT)

### Opção A: Importação Rápida via Arquivo ZIP
1. No ChatGPT, acesse **Explore GPTs** -> **Create a GPT** (ou configure um GPT existente).
2. Na aba **Configure**, no rodapé, clique em **Actions** -> **Create new action** (ou upload de arquivo de schema).
3. Se o ChatGPT solicitar upload do bundle, anexe este arquivo `firstsys-zatten-mcp-bundle.zip`.
4. Em **Authentication**, selecione **OAuth**:
   - **Client ID:** *(gerado na criação do cliente na Central ou fornecido pela Firstsys)*
   - **Client Secret:** *(fornecido pela Firstsys)*
   - **Authorization URL:** `https://firstend.firstsys.com.br/oauth/authorize`
   - **Token URL:** `https://firstend.firstsys.com.br/oauth/token`
   - **Scope:** `profile connections:read zatten:read zatten:write zatten:messages`
5. Na caixa de **Instructions** do GPT, copie e cole o texto do arquivo `instructions.md`.
6. Salve o GPT e teste a autenticação!

### Opção B: Importação Direta via URL
1. No campo **Schema**, importe a URL pública:
   ```
   https://firstend.firstsys.com.br/openapi.json
   ```
2. Configure a autenticação OAuth 2.1 conforme os links acima.
